<?php include 'header.php';?>
        <div class="addTermsPage"></div>
		<div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="header">
                              <h4 class="title">Add terms and condition for MAI</h4>
                            </div>
                            <div class="content">
                                <form>
                                    <div class="row">
                                        
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Add content here</label>
                                                <textarea rows="10" class="form-control" placeholder="Here can be your terms and conditions" value=""></textarea>
                                            </div>
                                        </div>
                                    </div>

                                    <button type="submit" class="btn btn-info btn-fill pull-right">Update</button>
                                    <div class="clearfix"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>

<?php include 'footer.php';?>
